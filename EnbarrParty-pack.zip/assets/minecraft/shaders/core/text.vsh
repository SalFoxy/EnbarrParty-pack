#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 text.vsh plus one thing for the EnbarrParty HUD: on screen (IS_GUI), text whose colour carries
// the side marker (red & 7 == 5, green & 7 == 6, blue & 7 == 2) is moved from the centre of the screen to its
// left edge. The plugin draws the side panel (turn order, your things) in a boss bar whose text starts exactly at
// the centre, so after the move it starts at the left edge.
// Text with the dialog marker (red & 7 == 5, green & 7 == 3, blue & 7 == 4) is moved up by 80 GUI pixels: the
// NPC dialog box is drawn in the action bar, just above the hotbar, and a font can only move letters down from
// there (see tools/textures/dialog.py).
// A marker is 9 bits of the colour, so other text (server MOTDs with gradients, chat) carries one by chance only
// once in 512 colours; on top of that it counts only where our text can be: the side panel in the top part of the
// right half of the screen (before the move), the dialog box in the bottom strip. Any other text is drawn as in
// vanilla.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#ifdef IS_GUI
    ivec3 rgb = ivec3(round(Color.rgb * 255.0));
    // GUI pixels: ProjMat is an orthographic projection with [0][0] = 2 / width and [1][1] = -2 / height
    vec2 gui = (ModelViewMat * vec4(Position, 1.0)).xy;
    vec2 screen = vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]);
    if ((rgb.r & 7) == 5 && (rgb.g & 7) == 6 && (rgb.b & 7) == 2
            && gui.x >= screen.x * 0.5 - 4.0 && gui.y < 260.0) {
        // centre of the screen (x = 0 in clip space) to the left edge (x = -1)
        gl_Position.x -= gl_Position.w;
    } else if ((rgb.r & 7) == 5 && (rgb.g & 7) == 3 && (rgb.b & 7) == 4 && gui.y > screen.y - 90.0) {
        // GUI y grows downwards and ProjMat[1][1] is -2 / height: this is 80 GUI pixels up
        gl_Position.y -= 80.0 * ProjMat[1][1] * gl_Position.w;
    }
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
